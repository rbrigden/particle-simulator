import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class simulator extends PApplet {

//  Author: Ryan Brigden
//  This program simulates charged particles in an environment with electromagnetic forces at play.

//  External Sources:
//  https://processing.org/examples/polartocartesian.html
//  https://processing.org/examples/bounce.html
//  https://processing.org/examples/spring.html
//  https://processing.org/examples/multipleparticlesystems.html
//  Asked Jake Herman about implementing multiple particles in simulation, advised me to separate update and draw methods.
//  He also helped me implement a technique to update the acceleration many times between frames in order to increase accuracy.
//  Abhinav Venigalla taught me how to change the color of specific objects (in this case the particles) by turning the fill on
//  before drawing and then switching it off immediately afterwards.

// Class Descriptions:
// Particle (xpos, ypos, xspeed, yspeed, charge, mass)
// MagneticField (xpos, ypos, height, width, strength)
// ElectricField (xpos, ypos, height, width, strength, direction (boolean) )

ArrayList<Particle> particles;
ArrayList<MagneticField> mag_fields;
ArrayList<ElectricField> electric_fields;

public void setup(){
  // initialize particles and fields
  particles = new ArrayList<Particle>();
  mag_fields = new ArrayList<MagneticField>();
  electric_fields = new ArrayList<ElectricField>();
  
  // draw canvas
  size(1280, 640);
  stroke(255);
  
  // add magnetic fields to the system
  mag_fields.add(new MagneticField(0, 160, 320, 400, 1));
  mag_fields.add(new MagneticField(880, 160, 320, 400, 1));
  
  // add electric fields to the system
  electric_fields.add(new ElectricField(width/4 + 150, height/4, 300, 400, 4, true));
  
  // add particles to the system
  float xi = width/2;
  float yi = height/2;
  
  particles.add(new Particle(xi, yi, 4, 0, 1, 20));
  particles.add(new Particle(xi, yi, 9, 1, -1, 20));
  particles.add(new Particle(xi, yi, 4, 0, -1, 20));
  particles.add(new Particle(xi, yi, 8, -2, 1, 20));
}

public void draw(){
  background(155);
  
  // build magnetic fields
  for (MagneticField field : mag_fields){
    field.buildField();
  }
  
  // build electric fields
  for (ElectricField field : electric_fields){
    field.buildField();
  }
  
  int rad = 10;
  float dt = 0.001f;
  
  for(Particle p : particles) {
    for(int i = 0; i < 1000; i++) {
      p.update(dt, mag_fields, electric_fields);
    }
    // if negatively charged
    if (p.charge < 0){
      fill(0xff12D1FF);
      stroke(0xff12D1FF);
      ellipse(p.xpos, p.ypos, rad, rad);
      fill(155);
      stroke(255);
    }
    // if positively charged
    else if (p.charge > 0){
      fill(0xffFF1515);
      stroke(0xffFF1515);
      ellipse(p.xpos, p.ypos, rad, rad);
      fill(155);
      stroke(255);
    }
    // if neutrally charged
    else {
      ellipse(p.xpos, p.ypos, rad, rad);
    }
  }
}
public class ElectricField{
  
  // electric field anchor points
  float x1;
  float y1; 
  float x2;
  float y2;
  
  // strength of the electric field: E
  float strength;
  
  // field faces right if true; left if false
  boolean right;

  // field dimensions
  float field_height;
  float field_width;
  
  // default electric field
  public ElectricField(){
    field_height = 250;
    field_width = 250;
    x1 = 250;
    y1 = 250;
    x2 = x1 + field_width;
    y2 = 250;
    right = true;
    strength = 1;
  }
    
  // custom electric field
  public ElectricField(float x, float y, float h, float w, float s, boolean r){
    field_height = h;
    field_width = w;
    x1 = x;
    y1 = y;
    x2 = x1 + w;
    y2 = y;
    strength = s;
    right = r;
  }
  
  // draw the electric field
  public void buildField(){
    line(x1, y1, x1, y1 + field_height);
    line(x2, y1, x2, y1 + field_height);
    
    for (int i = 0; i <= (int) field_height/30 ; i++)
    {
      float y = y1 + 30 * i;
      line(x1, y, x2, y);
      float midx = (x1 + x2) / 2; 
      if (right){
        line(midx, y, midx - 5, y + 5);
        line(midx, y, midx - 5, y - 5);
      }
      else{
        line(midx, y, midx + 5, y + 5);
        line(midx, y, midx + 5, y - 5);
      }
      
      
    }
  
  }
  
 
    
  
  
}

class MagneticField {
  
  // draw magnetic field points
  float x1; // = 250;
  float y1; // = 150;
  float x2;
  float y2;
  
  // initial values
  float x1_0; 
  float y1_0;
  float x2_0; 
  float y2_0;
  
  // field dimensions
  float field_height;
  float field_width;
  
  // strength of the field: B
  float strength;
  
  // default magnetic field
  public MagneticField(){
    x1 = 250;
    y1 = 250;
    x2 = x1 + 5;
    y2 = y1 + 5;
    x1_0 = x1;
    y1_0 = y1;
    x2_0 = x2;
    y2_0 = y2;
    
    field_height = 400;
    field_width = 800;
  }
  
  // custom magnetic field
  public MagneticField(float x, float y, float h, float w, float b){
    x1 = x;
    y1 = y;
    x2 = x + 5;
    y2 = y + 5;
    x1_0 = x1;
    y1_0 = y1;
    x2_0 = x2;
    y2_0 = y2;
    
    field_height = h;
    field_width = w;
    
    strength = b;
  }
  
  // draw the inward facing magnetic field (x)
  public void buildField(){
    for (int i = 0; i <= (int) field_height/30 ; i++)
    {
      for (int k = 0; k <= (int) field_width/30; k++)
      {
        x1 += 30;
        x2 += 30;
        line(x1,y1,x2,y2);
        line(x1,y2,x2,y1);
      }
      y1 += 30;
      y2 += 30;
      x1 = x1_0;
      x2 = x2_0;
    }
    y1 = y1_0;
    y2 = y2_0;  
  }
  
}
/* Particle represents a charged particle.
   Particle(x,y,xspeed,yspeed,charge, mass
*/

class Particle{
  // position of the particle
  float xpos;
  float ypos;
  
  // speed of the particle
  float xspeed;
  float yspeed;
  
  // particle qualities
  float charge;
  float mass;
  
  
  public Particle() {
    xpos = 30;
    ypos = 310;
    xspeed = 3;
    yspeed = 0;
    charge = 1;
    mass = 0.1f;
  }
  
  public Particle(float x, float y, float xspd, float yspd, float q, float m) {
    xpos = x;
    ypos = y;
    xspeed = xspd;
    yspeed = yspd;
    charge = q;
    mass = m;
    
  }
  
  
  public void update(float dt, ArrayList<MagneticField> mag_fields, ArrayList<ElectricField> electric_fields){
    // test for inclusiveness and accelerate inside the magnetic field
    for (MagneticField field : mag_fields){
      if (inMagField(field)){
          accelerateInMagField(dt, field);
        }
     }
     
     // test for inclusiveness and accelerate inside the electric field
      for (ElectricField field : electric_fields){
      if (inElectricField(field)){
          accelerateInElectricField(dt, field);
        }
     }
     
     sides();
     xpos += xspeed * dt;
     ypos += yspeed * dt;
  }
  
  private void sides(){
  
    // side window barriers
    if (xpos > width && xspeed > 0) { 
      xspeed = -1 * xspeed; 
    }
    
    if (xpos < 0 && xspeed < 0) { 
      xspeed = -1 * xspeed; 
    }
    
    // top and bottom window barriers
    if (ypos > height && yspeed > 0) { 
      yspeed = -1 * yspeed; 
    }
    
    if (ypos < 0 && yspeed < 0) { 
      yspeed = -1 * yspeed; 
    }
  }
  
  // check if this particle is within a given magnetic field
  private boolean inMagField(MagneticField field){
    float field_width = field.field_width;
    float field_height = field.field_height;
    float x1 = field.x1;
    float y1 = field.y1;
    return xpos > x1 && xpos < (x1 + field_width) && ypos > y1 && ypos < (y1 + field_height);
  }
  
  // check if this particle is within a given electric field
  private boolean inElectricField(ElectricField field){
    float field_width = field.field_width;
    float field_height = field.field_height;
    float x1 = field.x1;
    float y1 = field.y1;
    return xpos > x1 && xpos < (x1 + field_width) && ypos > y1 && ypos < (y1 + field_height);
  }
  
  // accelerate this particle in a given magnetic field
  private void accelerateInMagField(float dt, MagneticField field){
    float speed = getMagnitude(xspeed, yspeed);
    float acc = getMagAcc(field);
    
    float yacc = ((xspeed / speed) * acc);
    float xacc = ((yspeed / speed) * acc) * -1;
   
    xspeed += xacc * dt;
    yspeed += yacc * dt;
  }
  
  // accelerate this particle in a given electric field
  private void accelerateInElectricField(float dt, ElectricField field){
    float xacc = (field.strength * charge) / mass;
    if (!field.right){
      xacc *= -1;
    }
    
    xspeed += xacc * dt;   
  }
  
  
  
  // magnitude of a vector
  private float getMagnitude(float a, float b){
      return (float) Math.sqrt(a * a + b * b);
  }
  
  // magnitude of the acceleration caused by the magnetic field
  private float getMagAcc(MagneticField field){
    float speed = getMagnitude(xspeed, yspeed);
    return (charge * speed * field.strength * -1) / mass;
  }
  
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--stop-color=#cccccc", "simulator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
